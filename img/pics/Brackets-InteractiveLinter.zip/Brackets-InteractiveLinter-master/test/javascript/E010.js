with(object){

}


var test = {
    "badJson":
};