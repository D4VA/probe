function successCallback (fileEntry) {
    console.log(fileEntry);
}

successCallback(null);
