/*jshint esnext: true */
const CONST_1 = 10;
const CONST_1 = 20;